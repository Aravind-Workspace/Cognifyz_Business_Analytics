import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv('Data_set 2 - copy.csv')


#Explore Expectations Column
# Display the first 5 rows of the dataset
print(df.head())

# Explore Expectations Column
expectations = df['Expect']
print(expectations.describe())

# List and Describe Expectations
common_expectations = expectations.value_counts().head(10)
print("The 10 most common expectations are:")
print(common_expectations)


# Select relevant columns
relevant_columns = df[['age', 'Duration', 'Expect']]
print(relevant_columns.head())



# Use statistical methods or visualizations
correlation = relevant_columns.corr()
print(correlation)

# Visualize correlation using scatter plots
plt.scatter(relevant_columns['age'], relevant_columns['Duration'])
plt.xlabel('Age')
plt.ylabel('Investment Duration')
plt.show()

plt.scatter(relevant_columns['age'], relevant_columns['Expect'])
plt.xlabel('Age')
plt.ylabel('Expected Returns')
plt.show()

plt.scatter(relevant_columns['Duration'], relevant_columns['Expect'])
plt.xlabel('Investment Duration')
plt.ylabel('Expected Returns')
plt.show()