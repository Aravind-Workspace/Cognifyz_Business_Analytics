import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv('Data_set 2 - copy.csv')

# Display the first 5 rows of the dataset
print(df.head())

# Get descriptive statistics
print(df.info())