import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv('Data_set 2 - copy.csv')

# Display the first 5 rows of the dataset
print(df.head())


#Calculate Average Duration
average_duration = investment_duration.mean()
print("The average investment duration is:", average_duration)
# Convert average duration to a specific format
def convert_duration_format(Duration):
    if Duration < 1:
        return "Less than 1 year"
    elif Duration < 2:
        return "1-2 years"
    elif Duration < 3:
        return "2-3 years"
    else:
        return "3 years or more"

average_duration_formatted = convert_duration_format(average_duration)
print("The average investment duration is:", average_duration_formatted)