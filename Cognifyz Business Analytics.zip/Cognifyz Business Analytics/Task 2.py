import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv('Data_set 2 - copy.csv')

# Display the first 5 rows of the dataset
print(df.head())

# Get descriptive statistics
print(df.info())

gender = df['gender']
print(gender)

# Get the value counts of each gender
gender_counts = gender.value_counts()

# Create a bar chart
gender_counts.plot(kind='bar')
plt.title('Distribution of Genders in Dataset')
plt.xlabel('Gender')
plt.ylabel('Count')
plt.show()