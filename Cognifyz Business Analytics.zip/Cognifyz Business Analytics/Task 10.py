import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv('Data_set 2 - copy.csv')


# Analyze Savings Objectives
savings_objectives = df['What are your savings objectives?']
print(savings_objectives.describe())


# List and Describe Objectives
common_objectives = savings_objectives.value_counts().head(10)
print("The 10 most common savings objectives are:")
print(common_objectives)