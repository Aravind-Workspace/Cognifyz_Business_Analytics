import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv('Data_set 2 - copy.csv')


#Explore Expectations Column
# Display the first 5 rows of the dataset
print(df.head())

# Explore Expectations Column
expectations = df['Expect']
print(expectations.describe())

# List and Describe Expectations
common_expectations = expectations.value_counts().head(10)
print("The 10 most common expectations are:")
print(common_expectations)