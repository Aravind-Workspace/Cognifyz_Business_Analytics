import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv('Data_set 2 - copy.csv')

# Display the first 5 rows of the dataset
print(df.head())

# Get descriptive statistics
print(df.info())

gender = df['gender']
print(gender)

# Get the value counts of each gender
gender_counts = gender.value_counts()

# Create a bar chart
gender_counts.plot(kind='bar')
plt.title('Distribution of Genders in Dataset')
plt.xlabel('Gender')
plt.ylabel('Count')
plt.show()


#Identify Numerical Columns
numerical_columns = df.select_dtypes(include=['int64', 'float64'])
print(numerical_columns.columns)



# Calculate the mean for each numerical column
mean_values = numerical_columns.mean()
print("Mean:")
print(mean_values)

# Calculate the median for each numerical column
median_values = numerical_columns.median()
print("\nMedian:")
print(median_values)

# Calculate the standard deviation for each numerical column
std_values = numerical_columns.std()
print("\nStandard Deviation:")
print(std_values)


#Explore Reasons Column
reason1 = df['Reason_Mutual']
reason2 = df['Reason_Bonds']
reason3 = df['Reason_FD']
print(reason1.value_counts())
print(reason2.value_counts())
print(reason3.value_counts())